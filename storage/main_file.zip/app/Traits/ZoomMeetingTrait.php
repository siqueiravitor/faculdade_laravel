<?php

namespace App\Traits;

use App\Models\ZoomSetting;
use Illuminate\Support\Facades\Auth;
use Log;

/**
 * trait ZoomMeetingTrait
 */
trait ZoomMeetingTrait
{
    
}
